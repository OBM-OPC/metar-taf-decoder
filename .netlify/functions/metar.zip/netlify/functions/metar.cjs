"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/metar.ts
var metar_exports = {};
__export(metar_exports, {
  config: () => config,
  default: () => metar_default
});
module.exports = __toCommonJS(metar_exports);
var emergencyStations = {
  "EDFV": { lat: 49.4733, lon: 8.1964 },
  // Bad Dürkheim
  "EDFE": { lat: 50.0383, lon: 8.6464 },
  // Egelsbach
  "EDDR": { lat: 49.2146, lon: 7.1095 }
  // Saarbrücken
};
async function lookupStationViaNominatim(icao) {
  try {
    const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(icao + " airport")}&format=json&limit=1`;
    const resp = await fetch(url, {
      headers: {
        "User-Agent": "METAR-Decoder/1.0 (metar-decoder.netlify.app)",
        Accept: "application/json"
      },
      signal: AbortSignal.timeout(5e3)
    });
    if (!resp.ok) return null;
    const data = await resp.json();
    if (Array.isArray(data) && data.length > 0) {
      const hit = data[0];
      if (hit.lat && hit.lon) {
        console.log("Nominatim found:", icao, hit.lat, hit.lon, hit.class, hit.type);
        return { lat: parseFloat(hit.lat), lon: parseFloat(hit.lon) };
      }
    }
  } catch (e) {
    console.log("Nominatim lookup error:", e);
  }
  return null;
}
function haversineDistance(lat1, lon1, lat2, lon2) {
  const R = 3440;
  const toRad = (deg) => deg * (Math.PI / 180);
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}
var metar_default = async (req) => {
  const url = new URL(req.url);
  const icao = url.searchParams.get("ids");
  if (!icao) {
    return new Response(JSON.stringify({ error: "Missing ids parameter" }), {
      status: 400,
      headers: { "Content-Type": "application/json" }
    });
  }
  const upperIcao = icao.toUpperCase();
  try {
    console.log("Fetching METAR for:", upperIcao);
    const metarResponse = await fetch(
      `https://aviationweather.gov/api/data/metar?ids=${upperIcao}&format=json&taf=false`,
      { headers: { Accept: "application/json" } }
    );
    if (metarResponse.ok) {
      const text = await metarResponse.text();
      if (text && text.trim()) {
        try {
          const metarData = JSON.parse(text);
          if (Array.isArray(metarData) && metarData.length > 0 && metarData[0].icaoId) {
            return new Response(JSON.stringify({ found: true, station: upperIcao, data: metarData }), {
              status: 200,
              headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
              }
            });
          }
        } catch (e) {
          console.log("METAR parse error:", e);
        }
      }
    }
    console.log("No direct METAR found for:", upperIcao);
    let stationLat = 0;
    let stationLon = 0;
    let hasStation = false;
    try {
      console.log("Fetching station info for:", upperIcao);
      const stationResponse = await fetch(
        `https://aviationweather.gov/api/data/stationinfo?ids=${upperIcao}&format=json`,
        { headers: { Accept: "application/json" } }
      );
      if (stationResponse.ok) {
        const text = await stationResponse.text();
        if (text && text.trim()) {
          try {
            const stationData = JSON.parse(text);
            if (Array.isArray(stationData) && stationData.length > 0) {
              stationLat = stationData[0].lat || 0;
              stationLon = stationData[0].lon || 0;
              hasStation = true;
              console.log("Station found via API:", upperIcao, "lat:", stationLat, "lon:", stationLon);
            }
          } catch (e) {
            console.log("Station parse error:", e);
          }
        }
      }
    } catch (e) {
      console.log("Station fetch error:", e);
    }
    if (!hasStation) {
      const nominatimResult = await lookupStationViaNominatim(upperIcao);
      if (nominatimResult) {
        stationLat = nominatimResult.lat;
        stationLon = nominatimResult.lon;
        hasStation = true;
        console.log("Station found via Nominatim:", upperIcao, "lat:", stationLat, "lon:", stationLon);
      }
    }
    if (!hasStation) {
      const emergency = emergencyStations[upperIcao];
      if (emergency) {
        stationLat = emergency.lat;
        stationLon = emergency.lon;
        hasStation = true;
        console.log("Station found via emergency DB:", upperIcao, "lat:", stationLat, "lon:", stationLon);
      }
    }
    let nearbyData = [];
    if (hasStation && stationLat !== 0 && stationLon !== 0) {
      try {
        const bbox = `${stationLat - 1},${stationLon - 1},${stationLat + 1},${stationLon + 1}`;
        console.log("Searching bbox:", bbox);
        const nearbyResponse = await fetch(
          `https://aviationweather.gov/api/data/metar?format=json&bbox=${bbox}`,
          { headers: { Accept: "application/json" } }
        );
        if (nearbyResponse.ok) {
          const text = await nearbyResponse.text();
          if (text && text.trim()) {
            try {
              const parsed = JSON.parse(text);
              if (Array.isArray(parsed) && parsed.length > 0) {
                nearbyData = parsed;
                console.log("Found nearby METARs:", parsed.length);
              }
            } catch (e) {
              console.log("Nearby parse error:", e);
            }
          }
        }
      } catch (e) {
        console.log("Nearby fetch error:", e);
      }
    }
    if (nearbyData.length === 0) {
      try {
        const prefix = upperIcao.substring(0, 2);
        let bbox = "47,5,55,15";
        if (prefix === "K" || prefix === "P") bbox = "24,-125,50,-65";
        else if (prefix === "C") bbox = "41,-141,84,-52";
        else if (prefix === "Y") bbox = "-40,110,-10,160";
        else if (prefix === "V") bbox = "5,70,40,140";
        console.log("Regional bbox:", bbox);
        const regionResponse = await fetch(
          `https://aviationweather.gov/api/data/metar?format=json&bbox=${bbox}`,
          { headers: { Accept: "application/json" } }
        );
        if (regionResponse.ok) {
          const text = await regionResponse.text();
          if (text && text.trim()) {
            try {
              const parsed = JSON.parse(text);
              if (Array.isArray(parsed) && parsed.length > 0) {
                nearbyData = parsed;
                console.log("Found regional METARs:", parsed.length);
              }
            } catch (e) {
              console.log("Regional parse error:", e);
            }
          }
        }
      } catch (e) {
        console.log("Regional fetch error:", e);
      }
    }
    if (nearbyData.length > 0) {
      if (upperIcao.startsWith("ED")) {
        nearbyData = nearbyData.filter((m) => m.icaoId.startsWith("ED"));
      }
      const withDistance = nearbyData.filter((m) => m.icaoId !== upperIcao).map((m) => ({
        ...m,
        distance: hasStation ? haversineDistance(stationLat, stationLon, m.lat, m.lon) : 999
      }));
      const sorted = hasStation ? withDistance.sort((a, b) => a.distance - b.distance) : withDistance;
      if (sorted.length > 0) {
        const nearest = sorted[0];
        const dist = hasStation ? Math.round(nearest.distance * 10) / 10 : null;
        console.log("Fallback station:", nearest.icaoId, "distance:", dist);
        return new Response(
          JSON.stringify({
            found: false,
            requested: upperIcao,
            fallback: true,
            fallbackStation: nearest.icaoId,
            fallbackDistance: dist,
            data: [nearest]
          }),
          {
            status: 200,
            headers: {
              "Content-Type": "application/json",
              "Access-Control-Allow-Origin": "*"
            }
          }
        );
      }
    }
    return new Response(
      JSON.stringify({ error: "Keine METAR-Daten f\xFCr diesen Flugplatz oder die Region verf\xFCgbar" }),
      {
        status: 404,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        }
      }
    );
  } catch (err) {
    console.error("METAR proxy error:", err);
    return new Response(JSON.stringify({ error: "Interner Serverfehler", details: err?.message || String(err) }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
};
var config = {
  path: "/api/metar"
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
